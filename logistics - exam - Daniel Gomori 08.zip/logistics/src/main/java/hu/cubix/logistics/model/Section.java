package hu.cubix.logistics.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;

@Entity
public class Section {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@ManyToOne
    @JoinColumn(name = "transport_plan_id")
    private TransportPlan transportPlan;
	
	private Long orderNumber;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "start_milestone_id")
    private Milestone startMilestone;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "end_milestone_id")
    private Milestone endMilestone;
	
	public Section(Long id, Long transportPlanId, Long orderNumber, Milestone startMilestone, Milestone endMilestone) {
		super();
		this.id = id;
//		this.setTransportPlan(setTransportPlan);
		this.orderNumber = orderNumber;
		this.startMilestone = startMilestone;
		this.endMilestone = endMilestone;
	}
	
	public Section() {
		super();
	}
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(Long orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Milestone getStartMilestone() {
		return startMilestone;
	}

	public void setStartMilestone(Milestone startMilestone) {
		this.startMilestone = startMilestone;
	}

	public Milestone getEndMilestone() {
		return endMilestone;
	}

	public void setEndMilestone(Milestone endMilestone) {
		this.endMilestone = endMilestone;
	}

	public void setTransportPlan(TransportPlan transportPlan) {
		this.transportPlan = transportPlan;		
	}
	
	
}
