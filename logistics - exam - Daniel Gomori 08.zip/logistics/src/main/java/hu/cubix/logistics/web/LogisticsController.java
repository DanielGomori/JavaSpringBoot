package hu.cubix.logistics.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import hu.cubix.logistics.dto.AddressDto;
import hu.cubix.logistics.mapper.LogisticsMapper;
import hu.cubix.logistics.model.Address;
import hu.cubix.logistics.service.LogisticsService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/addresses")
public class LogisticsController {

	@Autowired
	LogisticsService logisticsService;
	
	@Autowired
	LogisticsMapper logisticsMapper;
	
	
	@GetMapping
	public List<AddressDto> getAll(){
		return logisticsMapper.addressToDtos(logisticsService.findAll());
	}
	
	@GetMapping("/{id}")
	public AddressDto getById(@PathVariable long id) {
		Address address = logisticsService.findById(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
			return logisticsMapper.addressToDto(address);
	}
	
	@PostMapping
	public AddressDto createAddress(@RequestBody @Valid AddressDto addressDto){
		Address address = logisticsService.save(logisticsMapper.dtoToAddress(addressDto));
		return logisticsMapper.addressToDto(address);
	}
			
	@PostMapping("/search") //?page={page}&size={size}&sort={sort},{sortDir}") // /api/addresses/search?page=2&size=10&sort=city,desc
	public ResponseEntity<Page<AddressDto>> filterAddresses(
			@RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "10") int size,
            @RequestParam(required = false, defaultValue = "id,asc") String sort,
			@RequestBody Map<String, String> params) {
		String city  = params.get("city");
		String country = params.get("country");
		String street = params.get("street");
		String zipCode = params.get("zipCode");
		
		String[] sortParts = sort.split(",");
	    String sortField = sortParts[0];
	    Sort.Direction sortDirection = sortParts.length > 1 ?
                Sort.Direction.fromString(sortParts[1]) : Sort.Direction.ASC;

	    Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortField));

	    
	    Page<Address> addressPage = logisticsService.filterAddresses(city, country, street, zipCode, pageable);
        Page<AddressDto> addressDtoPage = logisticsMapper.addressPageToDtoPage(addressPage);

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Total-Count", String.valueOf(addressDtoPage.getTotalElements()));
        
        if (!addressDtoPage.isEmpty()) {
	        return ResponseEntity.ok().body(addressDtoPage);
	    } else {
	        return ResponseEntity.badRequest().build();
	    }  
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<AddressDto> modifyAddress(@PathVariable long id,@RequestBody @Valid AddressDto addressDto) {
		Address address = logisticsMapper.dtoToAddress(addressDto);
		address.setId(id);
		AddressDto savedAddressDto = logisticsMapper.addressToDto(logisticsService.update(id, address));
		return ResponseEntity.ok(savedAddressDto);
	}
	
	@DeleteMapping("/{id}")
	public void deleteAddress(@PathVariable long id) {
		logisticsService.delete(id);
	}
	
	
}
