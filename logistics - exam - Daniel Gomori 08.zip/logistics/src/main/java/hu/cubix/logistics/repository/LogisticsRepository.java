package hu.cubix.logistics.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import hu.cubix.logistics.model.Address;

public interface LogisticsRepository extends JpaRepository<Address, Long>{
	
	@Query("SELECT a FROM Address a WHERE "
			+ "((:city IS NULL OR :city = '') OR LOWER(a.city) LIKE LOWER(:city) || '%') AND "
			+ "((:country IS NULL OR :country = '') OR LOWER(a.country) LIKE LOWER(:country) || '%') AND "
			+ "((:street IS NULL OR :street = '') OR LOWER(a.street) LIKE LOWER(:street) || '%') AND "
			+ "((:zipCode IS NULL OR :zipCode = '') OR a.zipCode LIKE :zipCode)")
	Page<Address> filterAddresses(
            @Param("city") String city,
            @Param("country") String country,
            @Param("street") String street,
            @Param("zipCode") String zipCode,
            Pageable pageable);
//	List<Address> filterAddresses(
//            @Param("city") String city,
//            @Param("country") String country,
//            @Param("street") String street,
//            @Param("zipCode") String zipCode,
//            Sort  sort);

}