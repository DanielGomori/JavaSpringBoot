package hu.cubix.logistics.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hu.cubix.logistics.model.Milestone;
import hu.cubix.logistics.model.Section;
import hu.cubix.logistics.model.TransportPlan;
import hu.cubix.logistics.repository.MilestoneRepository;
import hu.cubix.logistics.repository.TransportPlanRepository;

@Service
public class TransportPlanServiceImpl implements TransportPlanService{

	@Autowired
	TransportPlanRepository transportPlanRepository;
	
	@Autowired
	MilestoneRepository milestoneRepository;
	
	@Value("${logistics.delay_1}")
	private double delay_1;
	
	@Value("${logistics.delay_2}")
	private double delay_2;
	
	@Value("${logistics.delay_3}")
	private double delay_3;
	
	@Value("${logistics.percentage.delay_1}")
	private double percentage_1;
	
	@Value("${logistics.percentage.delay_2}")
	private double percentage_2;
	
	@Value("${logistics.percentage.delay_3}")
	private double percentage_3;
	
	
	@Transactional
	public Optional<TransportPlan> registerDelay(TransportPlan transportPlan, Long milestoneId, int delayMinutes) {
		Map<Long, Section> sections = transportPlan.getSections();

		boolean continueForTheRest = false;
		boolean delayNextStartMileston = true;
		int income = transportPlan.getIncome();
		double decreasedIncome = 0;
		
		if (delayMinutes <= delay_1){
			decreasedIncome = income * percentage_1;
        } else if (delayMinutes <= delay_2) {
        	decreasedIncome = income * percentage_2;
        } else if (delayMinutes <= delay_3) {
        	decreasedIncome = income * percentage_3;
        }
		
	    for (Entry<Long, Section> entry : sections.entrySet()) {
	        Section section = entry.getValue();
	        Milestone startMilestone = section.getStartMilestone();
	        Milestone endMilestone = section.getEndMilestone();
	        
	        if (startMilestone.getId().equals(milestoneId) || continueForTheRest) {
	            LocalDateTime plannedTime = startMilestone.getPlannedTime();
	            LocalDateTime newPlannedTime = plannedTime.plusMinutes(delayMinutes);
	            if (delayNextStartMileston) {
		            milestoneRepository.registerDelay(startMilestone.getId(), newPlannedTime);
		            milestoneRepository.registerDelay(endMilestone.getId(), newPlannedTime);
		            continueForTheRest = true;
	            } else {
		            milestoneRepository.registerDelay(endMilestone.getId(), newPlannedTime);
		            continueForTheRest = true;
	            }
	        }
	        if (endMilestone.getId().equals(milestoneId) || continueForTheRest) {
	            LocalDateTime plannedTime = endMilestone.getPlannedTime();
	            LocalDateTime newPlannedTime = plannedTime.plusMinutes(delayMinutes);
	            milestoneRepository.registerDelay(endMilestone.getId(), newPlannedTime);
	            continueForTheRest = true;
	            delayNextStartMileston = true;
	        }
	        
	    }
	    if (!continueForTheRest) {
	        System.out.println("Section with milestone ID " + milestoneId + " not found.");
	        throw new NoSuchElementException();
	    }
	    else {
	    	transportPlanRepository.decreaseIncome(transportPlan.getId(),(int)decreasedIncome);
	    }

	    return transportPlanRepository.findById(transportPlan.getId());
	}
	

	@Override
	public List<TransportPlan> findAll() {
			return transportPlanRepository.findAll();
	}
	
	@Transactional
	public TransportPlan update(Long id, TransportPlan transportPlan) {
		if(transportPlanRepository.existsById(transportPlan.getId()))
			return transportPlanRepository.save(transportPlan);
		else
			throw new NoSuchElementException();
	}
	
	@Transactional
	public TransportPlan save(TransportPlan transportPlan) {
		return transportPlanRepository.save(transportPlan);
	}

	@Override
	public Optional<TransportPlan> findById(long id) {
		return transportPlanRepository.findById(id);
	}


	@Override
	public void decreaseIncome(Long id, Integer income) {
		transportPlanRepository.decreaseIncome(id, income);
	}
	
}
