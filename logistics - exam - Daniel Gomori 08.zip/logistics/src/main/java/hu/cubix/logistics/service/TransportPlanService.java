package hu.cubix.logistics.service;

import java.util.List;
import java.util.Optional;

import hu.cubix.logistics.model.TransportPlan;

public interface TransportPlanService {
	
	public List<TransportPlan> findAll();
	public Optional<TransportPlan> registerDelay(TransportPlan transportPlan, Long milestoneId, int delayMinutes);
	public TransportPlan update(Long id, TransportPlan transportPlan);
	public TransportPlan save(TransportPlan transportPlan);
	public Optional<TransportPlan> findById(long id);
	public void decreaseIncome(Long id, Integer income);
}
