package hu.cubix.logistics.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hu.cubix.logistics.model.Address;
import hu.cubix.logistics.model.TransportPlan;
import hu.cubix.logistics.repository.LogisticsRepository;
import hu.cubix.logistics.repository.TransportPlanRepository;

@Service
public class TransportService implements LogisticsService{

	@Autowired
	LogisticsRepository logisticsRepository;
	
	@Autowired
	TransportPlanRepository transportPlanRepository;
	
	@Override
	public int getIncomeFromTransportPlan(TransportPlan transportPlan) {
		return transportPlan.getIncome();
	}

	@Transactional
	public Address save(Address address) {
		return logisticsRepository.save(address);
	}

	@Override
	public List<Address> findAll() {
		return logisticsRepository.findAll();
		}

	@Override
	public Optional<Address> findById(long id) {
		return logisticsRepository.findById(id);
	}

	@Transactional
	public Address update(long id, Address address) {
		if(logisticsRepository.existsById(address.getId()))
			return logisticsRepository.save(address);
		else
			throw new NoSuchElementException();
	}

	@Transactional
	public void delete(long id) {
		logisticsRepository.deleteById(id);		
	}


	@Override
	public Page<Address> filterAddresses(String city, String country, String street, String zipCode, Pageable pageable) {
		return logisticsRepository.filterAddresses(city, country, street, zipCode, pageable);
	}

}
