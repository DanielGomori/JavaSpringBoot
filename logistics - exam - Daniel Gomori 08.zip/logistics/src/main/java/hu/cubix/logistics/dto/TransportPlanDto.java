package hu.cubix.logistics.dto;

import java.util.Map;

import hu.cubix.logistics.model.Section;
import jakarta.validation.constraints.Positive;

public class TransportPlanDto {

	private Long id;
	@Positive
	private int income;	
	private Map<Long, Section> sections;
	
	public TransportPlanDto(Long id, @Positive int income, Map<Long, Section> sections) {
		super();
		this.id = id;
		this.income = income;
		this.sections = sections;
	}
	
	public TransportPlanDto() {
		super();
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getIncome() {
		return income;
	}

	public void setIncome(int income) {
		this.income = income;
	}

	public Map<Long, Section> getSections() {
		return sections;
	}

	public void setSections(Map<Long, Section> sections) {
		this.sections = sections;
	}
	
}
