package hu.cubix.logistics.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import hu.cubix.logistics.dto.TransportPlanDto;
import hu.cubix.logistics.model.TransportPlan;

@Mapper(componentModel = "spring")
public interface TransportPlanMapper {

	TransportPlan dtoToTransportPlan = null;

	List<TransportPlanDto> transportPlanToDtos(List<TransportPlan> transportPlans);

	TransportPlanDto transportPlanToDto(TransportPlan transportPlan);

	TransportPlan dtoToTransportPlan(TransportPlanDto transportPlanDto);
	
}