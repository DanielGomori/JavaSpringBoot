package hu.cubix.logistics.model;

import java.util.Map;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MapKey;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Positive;

@Entity
public class TransportPlan {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Positive
	private int income;	
	@OneToMany(mappedBy = "transportPlan", cascade = CascadeType.ALL, orphanRemoval = true)
    @MapKey(name = "orderNumber")
	private Map<Long, Section> sections;

	
	public TransportPlan(Long id, int income) {
		super();
		this.id = id;
		this.income = income;
//		this.sections = sections;
	}

	public TransportPlan() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getIncome() {
		return income;
	}

	public void setIncome(int income) {
		this.income = income;
	}

	public Map<Long, Section> getSections() {
		return sections;
	}

	public void setSections(Map<Long, Section> sections) {
		this.sections = sections;
	}
	
	
}
