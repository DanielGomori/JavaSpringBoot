package hu.cubix.logistics.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import hu.cubix.logistics.model.Milestone;

public interface MilestoneRepository extends JpaRepository<Milestone, Long> {

	@Modifying
    @Query("UPDATE Milestone m SET m.plannedTime = :newPlannedTime WHERE m.id = :id")
    void registerDelay(Long id, LocalDateTime newPlannedTime);
	
	
}
