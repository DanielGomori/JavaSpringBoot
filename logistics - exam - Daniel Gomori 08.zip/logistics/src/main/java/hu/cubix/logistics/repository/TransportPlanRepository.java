package hu.cubix.logistics.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import hu.cubix.logistics.model.TransportPlan;

public interface TransportPlanRepository extends JpaRepository<TransportPlan, Long> {

	@Modifying
    @Query("UPDATE TransportPlan t SET t.income = :income WHERE t.id = :id")
    void decreaseIncome(Long id, Integer income);
}
