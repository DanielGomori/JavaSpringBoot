package hu.cubix.logistics.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import hu.cubix.logistics.model.Address;
import hu.cubix.logistics.model.TransportPlan;

public interface LogisticsService {

	public int getIncomeFromTransportPlan(TransportPlan transportPlan);
	public Address save(Address address);
	public Page<Address> filterAddresses(String city, String country, String street, String zipCode, Pageable pageable);
//	public List<Address> filterAddresses(Map<String, String> params, Sort sort);
	public Optional<Address> findById(long id);
	public Address update(long id, Address address);
	public void delete(long id);
//	public List<Address> filterAddresses(String country, String city, String street, String zipCode);

	public List<Address> findAll();
	 	
}
