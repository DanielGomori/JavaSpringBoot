package hu.cubix.logistics.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import hu.cubix.logistics.dto.AddressDto;
import hu.cubix.logistics.model.Address;

@Mapper(componentModel = "spring")
public interface LogisticsMapper {

	Address dtoToAddress = null;

	List<AddressDto> addressToDtos(List<Address> addresses);

	AddressDto addressToDto(Address address);

	Address dtoToAddress(AddressDto addressDto);

//	List<Address> addressToDtos(List<Address> filterAddresses);
	
	default Page<AddressDto> addressPageToDtoPage(Page<Address> addressPage) {
        List<AddressDto> addressDtos = addressPage.getContent().stream()
                                    .map(this::addressToDto)
                                    .collect(Collectors.toList());
        return new PageImpl<>(addressDtos, addressPage.getPageable(), addressPage.getTotalElements());
    }

	
}