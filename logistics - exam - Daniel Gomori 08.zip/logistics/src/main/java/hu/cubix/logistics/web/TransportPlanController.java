package hu.cubix.logistics.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import hu.cubix.logistics.dto.TransportPlanDto;
import hu.cubix.logistics.mapper.TransportPlanMapper;
import hu.cubix.logistics.model.TransportPlan;
import hu.cubix.logistics.service.TransportPlanService;

@RestController
@RequestMapping("/api/transportplans")
public class TransportPlanController {

    @Autowired
    TransportPlanService transportPlanService;

    @Autowired
    TransportPlanMapper transportPlanMapper;
    
    
    @GetMapping
	public List<TransportPlanDto> getAll(){
		return transportPlanMapper.transportPlanToDtos(transportPlanService.findAll());
	}

    @PostMapping
	public TransportPlanDto createTransportPlan(@RequestBody TransportPlanDto transportPlanDto){
    	TransportPlan transportPlan = transportPlanService.save(transportPlanMapper.dtoToTransportPlan(transportPlanDto));
		return transportPlanMapper.transportPlanToDto(transportPlan);
	}
    
    @PostMapping("/{id}/delay")
    public ResponseEntity<TransportPlanDto> registerDelay(@PathVariable long id, @RequestBody Map<String, Integer> params) {
    	
    	int intMilestoneId = params.get("milestoneId");
    	int delayMinutes = params.get("delayMinutes");
    	long milestoneId = Long.valueOf(intMilestoneId);
    	
    	TransportPlan transportPlan = transportPlanService.findById(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    	
    	TransportPlan savedTransportPlan = transportPlanService.registerDelay(transportPlan, milestoneId, delayMinutes)
    			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    	
    	return ResponseEntity.ok(transportPlanMapper.transportPlanToDto(savedTransportPlan));
	}
}