package hu.webuni.airport.service;

public interface DiscountService {
	
	public int getDiscountPercent(int totalPrice);

}
