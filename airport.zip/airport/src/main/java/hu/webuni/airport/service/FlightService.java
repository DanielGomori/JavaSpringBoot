package hu.webuni.airport.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.querydsl.core.types.ExpressionUtils;
import com.querydsl.core.types.Predicate;

import hu.webuni.airport.model.Airport;
import hu.webuni.airport.model.Flight;
import hu.webuni.airport.repository.AirportRepository;
import hu.webuni.airport.repository.FlightRepository;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class FlightService {

	private final AirportRepository airportRepository;
	private final FlightRepository flightRepository;

		@Transactional
		public Flight save(Flight flight) {
			flight.setTakeoff(airportRepository.findById(flight.getTakeoff().getId()).get());
			flight.setLanding(airportRepository.findById(flight.getLanding().getId()).get());
			return flightRepository.save(flight);
		}
		
		@Transactional
		public void createFlight() {
			Flight flight = new Flight();
			flight.setFlightNumber("dafda");
			flight.setTakeoff(airportRepository.findById(1L).get());
			flight.setLanding(airportRepository.findById(2L).get());
			flight.setTakeoffTime(LocalDateTime.of(2021, 4,10,10,0,0));
			flightRepository.save(flight);
		}

//		public List<Flight> findFlightsByExample(Flight example){
//			
//			long id = example.getId();
//			String flightNumber = example.getFlightNumber();
//			String takeoffIata = null;
//			Airport takeoff = example.getTakeoff();
//			if(takeoff != null)
//				takeoffIata = takeoff.getIata();
//			LocalDateTime takeoffTime = example.getTakeoffTime();
//			
//			Specification<Flight> spec = Specification.where(null);
//			
//			
//			if(id > 0) {
//				spec = spec.and(FlightSpecifications.hasId(id));
//			}
//			if (StringUtils.hasText(flightNumber))
//				spec = spec.and(FlightSpecifications.hasFlightNumber(flightNumber));
//			
//			if (StringUtils.hasText(takeoffIata))
//				spec = spec.and(FlightSpecifications.hasTakeoffIata(takeoffIata));
//			
//			if (takeoffTime != null)
//				spec = spec.and(FlightSpecifications.hasTakeoffTime(takeoffTime));
//			
//			return flightRepository.findAll(spec, Sort.by("id"));
//		}
		
		public List<Flight> findFlightsByExample(Flight example){
			
			long id = example.getId();
			String flightNumber = example.getFlightNumber();
			String takeoffIata = null;
			Airport takeoff = example.getTakeoff();
			if(takeoff != null)
				takeoffIata = takeoff.getIata();
			LocalDateTime takeoffTime = example.getTakeoffTime();
			LocalDateTime startOfDay = takeoffTime.toLocalDate().atStartOfDay();
			
			ArrayList<Predicate> predicates = new ArrayList<Predicate>();
			
			QFlight flight = QFlight.flight;
			
			if(id > 0) {
				predicates.add(flight.id.eq(id));
			}
			if (StringUtils.hasText(flightNumber))
				predicates.add(flight.flightNumber.startWithIgnoreCase(flightNumber));
			
			if (StringUtils.hasText(takeoffIata))
				predicates.add(flight.takeoff.iata.startWith(takeoffIata));
			
			if (takeoffTime != null) {
				
				predicates.add(flight.takeoffTime.between(startOfDay, startOfDay.plusDays(1)));
			}
				
				
			return Lists.newArrayList(flightRepository.findAll(ExpressionUtils.allOf(predicates)));
		}


	}
