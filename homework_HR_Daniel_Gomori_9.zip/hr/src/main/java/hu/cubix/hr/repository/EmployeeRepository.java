package hu.cubix.hr.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import hu.cubix.hr.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{
	
	@Query("SELECT e FROM Employee e WHERE e.position LIKE :position")
	List<Employee> filterEmployeesByPosition(String position);
	
	@Query("SELECT e FROM Employee e WHERE e.name LIKE :prefix%")
	List<Employee> filterEmployeesByPrefix(String prefix);
	
	@Query("SELECT e FROM Employee e WHERE e.startTime between :startDate and :endDate")
	List<Employee> filterEmployeesWorkedBetweenDates(LocalDateTime startDate, LocalDateTime endDate);
	
	
	

}
