package hu.cubix.hr.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import hu.cubix.hr.model.Employee;

public interface EmployeeService {
	
	public int getPayRaisePercent(Employee employee);
	
	public Employee save(Employee employee);
	public List<Employee> findAll();
	public Optional<Employee> findById(long id);
	public Employee update(long id, Employee employee);
	public void delete(long id);
	public List<Employee> filterEmployeesByPosition(String position);
	public List<Employee> filterEmployeesByPrefix(String prefix);
	public List<Employee> filterEmployeesWorkedBetweenDates(LocalDateTime startDate, LocalDateTime leaveDate);
	
}
