package hu.cubix.hr.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import hu.cubix.hr.dto.EmployeeDto;
import hu.cubix.hr.model.Employee;

@Mapper(componentModel = "spring")
public interface EmployeeMapper {

	Employee dtoToEmployee = null;

	List<EmployeeDto> employeeToDtos(List<Employee> employees);

	EmployeeDto employeeToDto(Employee employee);

	Employee dtoToEmployee(EmployeeDto employeeDto);
}
