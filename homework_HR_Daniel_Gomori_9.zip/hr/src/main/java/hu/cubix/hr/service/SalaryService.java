package hu.cubix.hr.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.cubix.hr.model.Employee;
import hu.cubix.hr.repository.EmployeeRepository;

@Service
public class SalaryService implements EmployeeService {
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public SalaryService(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	public int getFinalSalaryRaise(Employee employee) {
		return (int)(employee.getSalary() * (1 + ((double)(employeeService.getPayRaisePercent(employee))/100.0)));
	}

	@Override
	public int getPayRaisePercent(Employee employee) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Employee save(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Employee> findById(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee update(long id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Employee> filterEmployeesByPosition(String position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> filterEmployeesByPrefix(String prefix) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> filterEmployeesWorkedBetweenDates(LocalDateTime startTime, LocalDateTime leaveTime) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
