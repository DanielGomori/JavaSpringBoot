package hu.cubix.hr.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import hu.cubix.hr.model.Employee;

@Service
public class DefaultEmployeeService extends HrService{

	@Value("${hr.salaryraise.def.percent}")
	private int defaultPercent;
	
	public int getPayRaisePercent(Employee employee) {
		return defaultPercent;
	}

}
