package hu.cubix.hr.web;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import hu.cubix.hr.dto.EmployeeDto;
import hu.cubix.hr.mapper.EmployeeMapper;
import hu.cubix.hr.model.Employee;
import hu.cubix.hr.service.EmployeeService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/employees")
public class HrController {
	
	@Autowired
	EmployeeService employeeService;

	@Autowired
	EmployeeMapper employeeMapper;
	
	
	@GetMapping
	public List<EmployeeDto> getAll(){
		return employeeMapper.employeeToDtos(employeeService.findAll());
	}
	
	@GetMapping("/{id}")
	public EmployeeDto getById(@PathVariable long id) {
		Employee employee = employeeService.findById(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
			return employeeMapper.employeeToDto(employee);
	}
	
	@PostMapping
	public EmployeeDto createEmployee(@RequestBody @Valid EmployeeDto employeeDto){
		Employee employee = employeeService.save(employeeMapper.dtoToEmployee(employeeDto));
		return employeeMapper.employeeToDto(employee);
	}
	
	@GetMapping("/filterbysalary/{salary}")
	public ResponseEntity<List<EmployeeDto>> filterBySalary(@PathVariable int salary) {
		List<EmployeeDto> ListOfEmployees =  employeeMapper.employeeToDtos(employeeService.findAll());
		List<EmployeeDto> filteredEmployees = new ArrayList<>();
		if(ListOfEmployees != null) {

			for (EmployeeDto employeeDto : ListOfEmployees) {
		        if (employeeDto.getSalary() > salary) {
		            filteredEmployees.add(employeeDto);
		        	}
				}
			}    
			if(!filteredEmployees.isEmpty())
				return ResponseEntity.ok(filteredEmployees);
			else
				return ResponseEntity.notFound().build();
		}
	
	@PutMapping("/{id}")
	public ResponseEntity<EmployeeDto> modifyEmployee(@PathVariable long id,@RequestBody @Valid EmployeeDto employeeDto) {
		Employee employee = employeeMapper.dtoToEmployee(employeeDto);
		employee.setId(id);
		EmployeeDto savedEmployeeDto = employeeMapper.employeeToDto(employeeService.update(id, employee));
		return ResponseEntity.ok(savedEmployeeDto);
	}
	
	@DeleteMapping("/{id}")
	public void deleteEmployee(@PathVariable long id) {
		employeeService.delete(id);
	}
	
	@GetMapping("/getraisepercent")
	public int getRaisePercentage(@RequestBody EmployeeDto employeeDto) {
		return employeeService.getPayRaisePercent(employeeMapper.dtoToEmployee(employeeDto));
	}
	
	@GetMapping("/filterEmployeesByPosition={position}")
	public List<EmployeeDto>filterEmployeesByPosition(@PathVariable String position){
		return employeeMapper.employeeToDtos(employeeService.filterEmployeesByPosition(position));
	}
	
	@GetMapping("/filterEmployeesByPrefix={prefix}")
	public List<EmployeeDto>filterEmployeesByPrefix(@PathVariable String prefix){
		return employeeMapper.employeeToDtos(employeeService.filterEmployeesByPrefix(prefix));
	}
	
	@GetMapping("/filterEmployeesWorkedBetweenDates")
	public List<EmployeeDto>filterEmployeesWorkedBetweenDates(@RequestBody LocalDateTime startDate, LocalDateTime endDate){
		System.out.println(startDate + " - " + endDate);
		return employeeMapper.employeeToDtos(employeeService.filterEmployeesWorkedBetweenDates(startDate, endDate));
	}
	
	
	
	
}
