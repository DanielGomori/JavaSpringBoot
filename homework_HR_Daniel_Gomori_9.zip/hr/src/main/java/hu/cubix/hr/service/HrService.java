package hu.cubix.hr.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import hu.cubix.hr.model.Employee;
import hu.cubix.hr.repository.EmployeeRepository;

public abstract class HrService implements EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Transactional
	public Employee save(Employee employee) {
//		em.persist(employee);
		return employeeRepository.save(employee);
	}
	
	public List<Employee> findAll(){
		return employeeRepository.findAll();
//		return em.createQuery("SELECT a FROM employee a", Employee.class).getResultList();
	}
	
	public Optional<Employee> findById(long id) {
		return employeeRepository.findById(id);
//		return em.find(Employee.class, id);
	}
	
	@Transactional
	public Employee update(long id, Employee employee) {
		if(employeeRepository.existsById(employee.getId()))
			return employeeRepository.save(employee);
		else
			throw new NoSuchElementException();
//		return em.merge(employee);
	}
	
	@Transactional
	public void delete(long id) {
		employeeRepository.deleteById(id);
//		em.remove(findById(id));
	}
	
//	@Query("SELECT e FROM Employee e WHERE e.position LIKE :prefix%")
	public List<Employee> filterEmployeesByPosition(String position){
		return employeeRepository.filterEmployeesByPosition(position);
	}
	
//	@Query("SELECT e FROM Employee e WHERE e.name LIKE :prefix%")
	public List<Employee> filterEmployeesByPrefix(String prefix){
		return employeeRepository.filterEmployeesByPrefix(prefix);
	}
	
//	@Query("SELECT e FROM Employee e WHERE e.startTime between ?startDate and ?endDate")
	public List<Employee> filterEmployeesWorkedBetweenDates(LocalDateTime startDate, LocalDateTime endDate){
		return employeeRepository.filterEmployeesWorkedBetweenDates(startDate, endDate);
	}
	
	
	
	
	
	
	
	
	
}
