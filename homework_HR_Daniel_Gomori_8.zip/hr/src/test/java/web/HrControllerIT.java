import static org.assertj.core.api.Assertions.assertThat;

HrControllerIT.java

import java.util.Collections;



import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.web.reactive.server.WebTestClient;

import hu.cubix.hr.dto.EmployeeDto;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class HrControllerIT {

	private static final String BASE_URI="/api/employees";
	
	@Autowired
	WebTestClient webTestClient;
	
	@Test
	void testThatCreatedEmployeeIsListed() throws Exception {
		List<EmployeeDto> employeesBefore = getAllEmployees();
		
		EmployeeDto newEmployee = new EmployeeDto(1, "Daniel Gomori", 50000, "2020-01-02T00:00:00");
		createEmployee(newEmployee);
		
		List<EmployeeDto> employeesAfter = getAllEmployees();
		
		assertThat(employeesAfter.subList(0, employeesBefore.size()))
			.usingRecursiveFieldByFieldElementComparator()
			.containsExactlyElementsOf(employeesBefore);
		
		assertThat(employeesAfter.get(employeesAfter.size()-1))
			.usingRecursiveComparison()
			.isEqualTo(newEmployee);
	}

	private void createEmployee(EmployeeDto newEmployee) {
		webTestClient
		.post()
		.uri(BASE_URI)
		.bodyValue(newEmployee)
		.exchange()
		.expectStatus()
		.isOk();
		
	}

	private List<EmployeeDto> getAllEmployees() {
		List<EmployeeDto> responseList = webTestClient
				.post()
				.uri(BASE_URI)
				.exchange()
				.expectStatus().isOk()
				.expectBodyList(EmployeeDto.class)			
				.returnResult().getResponseBody();
			
			Collections.sort(responseList, (e1,e2)-> Long.compare(e1.getId(), e2.getId()));
			
			return responseList;
		}


	@Test
	void testThatUpdatedEmployeeIsSaved(int id, EmployeeDto employeeDto) throws Exception {
		List<EmployeeDto> employees = getAllEmployees();
		EmployeeDto employeeBefore = employees.get(id);
		employeeBefore.setId(id);
		updateEmployee(employeeDto);
		
//		
//		EmployeeDto savedEmployeeDto = employeeMapper.employeeToDto(hrService.update(id, employee));
//		return ResponseEntity.ok(savedEmployeeDto);
//		
//		
//		
//		
	}

	private void updateEmployee(EmployeeDto employeeDto) {
		webTestClient
		.put()
		.uri(BASE_URI)
		.bodyValue(employeeDto)
		.exchange()
		.expectStatus()
		.isOk();
	}




}