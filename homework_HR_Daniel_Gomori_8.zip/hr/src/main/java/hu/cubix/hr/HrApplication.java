package hu.cubix.hr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import hu.cubix.hr.model.Employee;
import hu.cubix.hr.service.SalaryService;

@SpringBootApplication
public class HrApplication implements CommandLineRunner{

	@Autowired
	SalaryService salaryService;

	public static void main(String[] args) {
		SpringApplication.run(HrApplication.class, args);
	}
	Employee employee_test = new Employee(001, "Sarah Parker", 120000, "2021-08-02T00:00:00");
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println(salaryService.getFinalSalaryRaise(employee_test));
	}

}
