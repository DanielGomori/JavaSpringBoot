package hu.cubix.hr.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "hr")
@Component
public class HrConfigProperties {

	private SalaryRaise salaryraise = new SalaryRaise()
;	

	public SalaryRaise getSalaryraise() {
		return salaryraise;
	}

	public void setSalaryraise(SalaryRaise salaryraise) {
		this.salaryraise = salaryraise;
	}

	public static class SalaryRaise{
		private Default def = new Default();
		public Default getDef() {
			return def;
		}
		public void setDef(Default def) {
			this.def = def;
		}
	}
	
	public static class Default{
		private int percent;

		public int getPercent() {
			return percent;
		}

		public void setPercent(int percent) {
			this.percent = percent;
		}

	}
	
	public static class Smart{
			
		public static class Case_1{
			private int percent;
			public int getPercent() {
				return percent;
			}
			public void setPercent(int percent) {
				this.percent = percent;
			}
			public int getLimit() {
				return limit;
			}
			public void setLimit(int limit) {
				this.limit = limit;
			}
			private int limit;
		}
		public static class Case_2{
			private int percent;
			private int limit;
			public int getPercent() {
				return percent;
			}
			public void setPercent(int percent) {
				this.percent = percent;
			}
			public int getLimit() {
				return limit;
			}
			public void setLimit(int limit) {
				this.limit = limit;
			}
		}
		public static class Case_3{
			private int percent;
			private int limit;
			public int getPercent() {
				return percent;
			}
			public void setPercent(int percent) {
				this.percent = percent;
			}
			public int getLimit() {
				return limit;
			}
			public void setLimit(int limit) {
				this.limit = limit;
			}
		}
		public static class Case_4{
			private int percent;

			public int getPercent() {
				return percent;
			}

			public void setPercent(int percent) {
				this.percent = percent;
			}
		}
	}
}
