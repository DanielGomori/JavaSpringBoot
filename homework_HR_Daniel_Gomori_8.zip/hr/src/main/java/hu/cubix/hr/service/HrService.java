package hu.cubix.hr.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import hu.cubix.hr.model.Employee;

public abstract class HrService implements EmployeeService {

	private Map<Long, Employee> employees = new HashMap<>();
	{
		employees.put(1L, new Employee(1, "Daniel Gomori", 50000, "2020-01-02T00:00:00"));
		employees.put(2L, new Employee(2, "John Smith", 30000, "2022-04-02T00:00:00"));
		employees.put(3L, new Employee(3, "Laura Jones", 45000, "2023-01-02T00:00:00"));
		employees.put(4L, new Employee(4, "Laura Smith", 55000, "2023-01-02T00:00:00"));
	}
	
	public Employee save(Employee employee) {
		employees.put(employee.getId(), employee);
		return employee;
	}
	public List<Employee> findAll(){
		return new ArrayList<>(employees.values());
	}
	
	public Employee findById(long id) {
		return employees.get(id);
	}
	
	public Employee update(long id, Employee employee) {
		Employee employeeToUpdate = employees.get(id);
		employees.put(employeeToUpdate.getId(), employee);
		return employee;
	}
	
	public void delete(long id) {
		employees.remove(id);
	}
}
