package hu.cubix.hr.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Employee {

	private Long id;
	private String name;
	private int salary;
	private LocalDateTime startTime;
	
	public Employee(int id, String name, int salary, String startTime) {
		super();
		this.id = ((long)id);
		this.name = name;
		this.salary = salary;
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		this.startTime = LocalDateTime.parse(startTime, format);
	}
	
	public Employee() {
		super();
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public LocalDateTime getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		this.startTime = LocalDateTime.parse(startTime, format);
	}

}
