package hu.cubix.hr.dto;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public class EmployeeDto {
	
	private long id;
	
	@Size(min = 3, max = 20)
	private String name;
	@Positive
	private int salary;
	@PastOrPresent
	private LocalDateTime startTime;
	
	public EmployeeDto() {
	}
	
	public EmployeeDto(long id, String name, int salary, String startTime) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		this.startTime = LocalDateTime.parse(startTime, format);
	}
		
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public LocalDateTime getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		this.startTime = LocalDateTime.parse(startTime, format);
	}
	
	
}
