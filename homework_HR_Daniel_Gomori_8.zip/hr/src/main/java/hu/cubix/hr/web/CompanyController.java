package hu.cubix.hr.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hu.cubix.hr.dto.CompanyDto;
import hu.cubix.hr.dto.EmployeeDto;

@RestController
@RequestMapping("/api/companies")
public class CompanyController {
	
	boolean full = false;
			
	private Map<Long, CompanyDto> companies = new HashMap<>();
	
	Map<Long, EmployeeDto> employees = new HashMap<>();
	{
		employees.put(1L, new EmployeeDto(1, "Daniel Gomori", 50000, "2020-01-02T00:00:00"));
		employees.put(2L, new EmployeeDto(2, "John Smith", 30000, "2022-04-02T00:00:00"));
		employees.put(3L, new EmployeeDto(3, "Laura Jones", 45000, "2023-01-02T00:00:00"));
	}
	
	Map<Long, EmployeeDto> employees2 = new HashMap<>();
	{
		employees2.put(1L, new EmployeeDto(1, "Daniel Gomori", 50000, "2020-01-02T00:00:00"));
		employees2.put(2L, new EmployeeDto(2, "John Smith", 30000, "2022-04-02T00:00:00"));
		employees2.put(3L, new EmployeeDto(3, "Laura Jones", 45000, "2023-01-02T00:00:00"));
	}
	
	{
		companies.put(1L, new CompanyDto(1, 1234, "ABC Company", "Paris Main str 1", employees));
		companies.put(2L, new CompanyDto(2, 1564, "DEF Company", "Budapest Kossuth str 23", employees2));
	}
	
	
	@GetMapping
	public List<CompanyDto> getAll(){
		return new ArrayList<>(companies.values());
	}
	
	@GetMapping("/{id}") // Get Company by ID
	public ResponseEntity<CompanyDto> getById(@PathVariable long id) {
		CompanyDto companyDto = companies.get(id);
		if(companyDto != null)
			return ResponseEntity.ok(companyDto);
		else
			return ResponseEntity.notFound().build();
	}
	
	@GetMapping("/full={full}") // Get Company by ID
	public List<CompanyDto> getAllFull(@PathVariable boolean full) {
		if(full == false) {
			List<CompanyDto> result = new ArrayList<>();
	        for (CompanyDto company : companies.values()) {
	            CompanyDto modifiedCompany = new CompanyDto();
	            modifiedCompany.setId(company.getId());
	            modifiedCompany.setRegistrationNumber(company.getRegistrationNumber());
	            modifiedCompany.setName(company.getName());
	            modifiedCompany.setAddress(company.getAddress());
	            result.add(modifiedCompany);
	        }
			return result;
		}
		else {
			return new ArrayList<>(companies.values());
		}
	}
	
	@PostMapping
	public CompanyDto createCompany(@RequestBody CompanyDto companyDto){
		companies.put(companyDto.getId(), companyDto);
		return companyDto;
	}
	
	@PutMapping("/{id}") 
	public ResponseEntity<CompanyDto> modifyCompany(@PathVariable long id,@RequestBody CompanyDto companyDto) {
		if (!companies.containsKey(id)) {
			return ResponseEntity.notFound().build();
		}
		companyDto.setId(id);
		companies.put(id, companyDto);
		return ResponseEntity.ok(companyDto);
	}
	
	@DeleteMapping("/{id}")
	public void deleteCompany(@PathVariable long id) {
		companies.remove(id);
	}
	
	
	@PostMapping("/addemployee/{id}")
	public ResponseEntity<CompanyDto> addEmployee(@PathVariable long id, @RequestBody EmployeeDto employeeDto){
		if (!companies.containsKey(id)) {
			return ResponseEntity.notFound().build();
		}
		else {
			CompanyDto companyDto = companies.get(id);
			Map<Long, EmployeeDto> employees = companyDto.getEmployees();
			int sizeOfEmployeeList = employees.size();
			employees.put(Long.valueOf(sizeOfEmployeeList+1), employeeDto);
			companyDto.setEmployees(employees);
			
			return ResponseEntity.ok(companyDto);
		}
	}
		
	@DeleteMapping("/{id}/deleteemployee/{employeeId}")
	public void deleteEmployee(@PathVariable long id, @PathVariable Long employeeId) {
		Map<Long, EmployeeDto> employeesTemp = companies.get(id).getEmployees();
		employeesTemp.remove(employeeId);
		companies.get(id).setEmployees(employeesTemp);
	}
	
	@PostMapping("/replaceemployeelist/{id}") 
	public ResponseEntity<CompanyDto> replaceEmployeeList(@PathVariable long id,@RequestBody Map<Long, EmployeeDto> employeeDtoList) {
		if (!companies.containsKey(id)) {
			return ResponseEntity.notFound().build();
		}
		companies.get(id).setEmployees(employeeDtoList);
		return ResponseEntity.ok(companies.get(id));
	}
	
	
}
