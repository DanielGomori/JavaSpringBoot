package hu.cubix.hr.web;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import hu.cubix.hr.model.Employee;

@Controller
public class HrTLController {

	private List<Employee> allEmployees= new ArrayList<>();
	{
		allEmployees.add(new Employee(1, "Daniel Gomori", 50000, "2020-01-02T00:00:00"));
		allEmployees.add(new Employee(2, "John Smith", 30000, "2022-04-02T00:00:00"));
		allEmployees.add(new Employee(3, "Laura Jones", 45000, "2023-01-02T00:00:00"));
	}
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("/employees")
	public String listEmployees(Map<String, Object> model) {
		model.put("employees", allEmployees);
		model.put("newEmployee", new Employee());
		return "/employees";
	}
	@PostMapping("/employees")
	public String addEmployee(Employee employee) {
		allEmployees.add(employee);
		return "redirect:employees";
		
	}
	@GetMapping("/employees/edit/{id}")
    public String editEmployee(@PathVariable Long id, Model model) {
        Employee employee = findEmployeeById(id);
        if (employee != null) {
            model.addAttribute("employee", employee);
            return "edit";
        } else {
            return "redirect:/employees";
        }
	}
	
	private Employee findEmployeeById(Long id) {
		return allEmployees.stream()
	            .filter(employee -> employee.getId().equals(id))
	            .findFirst()
	            .orElse(null);
	}
	
	@PostMapping("/employees/edit/{id}")
    public String saveEditedEmployee(@PathVariable Long id, @ModelAttribute Employee editedEmployee) {
		updateEmployee(id, editedEmployee);
        return "redirect:/employees";
    }

	private boolean updateEmployee(Long id, Employee editedEmployee) {
	    for (int i = 0; i < allEmployees.size(); i++) {
	        Employee existingEmployee = allEmployees.get(i);
	        if (existingEmployee.getId().equals(id)) {
	            existingEmployee.setName(editedEmployee.getName());
	            existingEmployee.setSalary(editedEmployee.getSalary());
	            return true;
	        	}
	    	}return false;
	}

	@DeleteMapping("/employees/delete/{id}")
    public String deleteEmployee(@PathVariable Long id) {
        deleteEmployeeById(id);
        return "redirect:/employees";
    }
	
	private boolean deleteEmployeeById(Long id) {
	    for (Iterator<Employee> iterator = allEmployees.iterator(); iterator.hasNext(); ) {
	        Employee employee = iterator.next();
	        if (employee.getId().equals(id)) {
	            iterator.remove();
	            return true;
	        }
	    }
	    return false;
	}
	
}
	
	
