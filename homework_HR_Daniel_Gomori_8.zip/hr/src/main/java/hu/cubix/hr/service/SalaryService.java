package hu.cubix.hr.service;

import java.util.List;

import org.springframework.stereotype.Service;

import hu.cubix.hr.model.Employee;

@Service
public class SalaryService implements EmployeeService {
	
	EmployeeService employeeService;
	
	public SalaryService(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	public int getFinalSalaryRaise(Employee employee) {
		return (int)(employee.getSalary() * (1 + ((double)(employeeService.getPayRaisePercent(employee))/100.0)));
	}

	@Override
	public int getPayRaisePercent(Employee employee) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Employee save(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee findById(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee update(long id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(long id) {
		// TODO Auto-generated method stub
		
	}

	
}
