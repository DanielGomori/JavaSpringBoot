package hu.cubix.hr.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import hu.cubix.hr.model.Employee;

@Service
public class SmartEmployeeService extends HrService{
	
	@Value("${hr.salaryraise.smart.case_1.limit}")
	private double limit_1;
	
	@Value("${hr.salaryraise.smart.case_2.limit}")
	private double limit_2;
	
	@Value("${hr.salaryraise.smart.case_3.limit}")
	private double limit_3;
	
	
	@Value("${hr.salaryraise.smart.case_1.percent}")
	private int specialPercent_case_1;
	
	@Value("${hr.salaryraise.smart.case_2.percent}")
	private int specialPercent_case_2;
	
	@Value("${hr.salaryraise.smart.case_3.percent}")
	private int specialPercent_case_3;
	
	@Value("${hr.salaryraise.smart.case_4.percent}")
	private int specialPercent_case_4;
	
	
	private double getYearsPassed(LocalDateTime date) {
		LocalDate inputDate = date.toLocalDate();
		LocalDate currentDate = LocalDate.now();
        Period period = Period.between(inputDate, currentDate);
        
        int years = period.getYears();
        int months = period.getMonths();
        double periodInYears = years + (double) months / 12;
        return periodInYears;
        }
        
	public int getPayRaisePercent(Employee employee) {
		LocalDateTime startTime = employee.getStartTime();
		double x = this.getYearsPassed(startTime);
		int y;
	
		if (x < limit_1){
            y = specialPercent_case_1;
        } else if (x <= limit_2) {
            y = specialPercent_case_2;
        } else if (x <= limit_3) {
            y = specialPercent_case_3;
        } else {
            y = specialPercent_case_4;
        }
		return y;
	}

}

